
/**
* @author  Ganesh Kolandaivelu
* @version 1.0
* @since   2018-05-08 
*/
package com.election.count;
/**
 * The EvmConstants class declares the list of constants used in this
 * application. The constants are used in both Direct Addressing and Hash table
 * implementations for generation of index/hash values and for determining array
 * size
 */
class EvmConstants {

	// Declares the minimum value of the Voter ID, which is used as the LOW
	// value in (KEY-LOW) formula used in Direct Addressing Method.
	static final int VOTER_MIN = 100000;

	// Declares the maximum value of the Voter ID.
	static final int VOTER_MAX = 999999;

	// Declares the array size to hold Candidate and Voter details from EVM file
	// feed. This value is used as the modulo operator to calculate the hash value
	// in hash table implementation.
	static final int VOTER_ARRAY_SIZE = VOTER_MAX - VOTER_MIN + 1;

	// Declares the minimum value of the Candidate ID.
	static final int CANDIDATE_MIN = 100;

	// Declares the maximum value of the Candidate ID.
	static final int CANDIDATE_MAX = 999;

	// Declares the array size to hold the distinct Candidate IDs and its
	// corresponding count.
	static final int CANDIDATE_ARRAY_SIZE = CANDIDATE_MAX - CANDIDATE_MIN + 1;
}
