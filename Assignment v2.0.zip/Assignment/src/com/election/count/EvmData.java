/**
* @author  Ganesh Kolandaivelu
* @version 1.0
* @since   2018-05-08 
*/
package com.election.count;
/**
 * * The EvmData class declares the list of attributes that are part of EVM
 * feed. It is created separately as a class to represent it as a record and
 * each record can be added to a list of array to store the entire EVM feed.
 */
class EvmData {
	int voterID; // attribute to store Voter ID from EVM feed.
	int candidateID; // attribute to store Candidate ID from EVM feed.
}