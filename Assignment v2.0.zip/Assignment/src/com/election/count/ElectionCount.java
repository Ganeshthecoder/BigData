/**
* @author  Ganesh Kolandaivelu
* @version 1.0
* @since   2018-05-08 
*/
package com.election.count;
import java.util.Scanner;
/**
 * The ElectionCount class displays the menu options to the user and calls the
 * respective methods based on the inputs received.
 */
public class ElectionCount {
	// Declaring a Class variable to get user inputs in numeric value
	static Scanner scanInput = null;
	public static void main(String[] args) {

		// Declare a variable for user's option and defaulting to 0
		int menuOption = 0;
		try {
			// Initializing variable of type Scanner.
			scanInput = new Scanner(System.in);
			do {
				// Setting menuOption equal to return value from showMenu();
				menuOption = showMenu();

				// Switching on the value given from user
				switch (menuOption) {
					case 1 :
						// Instantiate ProcessEvmData class to instantiate array to store
						// EVM feed data
						new ProcessEvmData();
						// Call static method loadData by passing value '1', which indicates
						// the data loading will be done through Direct Addressing method
						ProcessEvmData.loadData(1);
						break;
					case 2 :
						// Instantiate ProcessEvmData class to instantiate array to store
						// EVM feed data
						new ProcessEvmData();
						// Call static method loadData by passing value '2', which indicates
						// the
						// the data loading will be done through Hash table method
						ProcessEvmData.loadData(2);
						break;
					case 3 :
						// Invoke findCandidate static method, which accepts the Voter ID as
						// input and prints the corresponding Candidate ID.
						ProcessEvmData.findCandidate();
						break;
					case 4 :
						// Invoke countOfVotes static method, which accepts the Voter ID as
						// input and prints the count of votes received by him.
						ProcessEvmData.countOfVotes();
						break;
					case 5 :
						System.out.println("\nProgram Exited. Thank You!");
						break;
					default :
						System.out.println("\nPlease enter a valid Option");
				}// End of switch statement
			} while (menuOption != 5);
		} finally {
			// closing Scanner resource at the end of the program.
			scanInput.close();
		}
	}// End of main Method

	/**
	 * Method that prints menu to screen and gets returns user's option from menu
	 * 
	 * Returns user Option
	 */
	static int showMenu() {
		// Declaring option variable for user option and defaulting to 0
		int option = 0;
		try {
			// Printing menu to screen
			System.out.println("\nMenu Options:\n");
			System.out.println("1. Load EVM data - Direct Addressing");
			System.out.println("2. Load EVM data - Hash Table");
			System.out.println("3. Find Candidate ID for the given Voter ID");
			System.out.println("4. Count of votes received by a Candidate ID");
			System.out.println("5. Quit Program");
			System.out.println("");
			// Getting user option from above menu
			System.out.print("Please enter option [1-5] : ");
			// To check if the user has entered a numeric value
			if (scanInput.hasNextInt()) {
				// Assign the user input to option variable
				option = scanInput.nextInt();
			} else {
				// Clear the scanner if the user has entered a non-numeric value
				scanInput.next();
			}
		} catch (Exception ex) {
			// Error Message
			ex.printStackTrace();
			System.out.println("Problem occured within Program");
			// flushing scanner
			scanInput.next();
		}
		return option;
	}
}