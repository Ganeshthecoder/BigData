/**
* @author  Ganesh Kolandaivelu
* @version 1.0
* @since   2018-05-08 
*/
package com.election.count;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * The ProcessEvmData class declares the array to store the EVM feed data and
 * the methods for ADD, FIND and COUNT operations
 * 
 * This class contains EvmData[] array (single array used for both
 * implementations), which stores the data from EVM feed using Direct Addressing
 * and Hash table implementations. The implementation method is decided based on
 * the Class variable processType, which is taken as an input from the user. If
 * processType is '1', then the data is loaded and stored in EvmData[] array
 * using Direct Addressing and if '2', then using Hash table.
 * 
 * This class also contains noOfVotes array to store the distinct Voter IDs and
 * its corresponding count of votes. This data is not loaded separately but
 * while loading the entire EVM data to the EvmData[] array, the corresponding
 * distinct Voter ID and its count is added here.
 * 
 * The method loadData accepts input from the user to decide the implementation.
 * if user selects '1', then the data is loaded and stored in EvmData[] array
 * using Direct Addressing and if '2', then using Hash table implementation.
 * While the records are added to EvmData[], the distinct Voter ID is added as a
 * key to another array noOfVotes[] with the corresponding count of votes as the
 * value. This is done to make the COUNT operation time complexity to O(1) and
 * to retrieve the data without for loops.
 * 
 * The method findCandidate accepts Voter ID as input and returns the Candidate
 * ID. This method is driven based on the Class variable processType. If
 * processType is '1', then the data is retrieved from EvmData[] array using
 * Direct Addressing and if '2', then using Hash table.
 * 
 * The method countOfVotes accepts the Voter ID as input and outputs the total
 * votes received by the Voter This method is driven based on the Class variable
 * processType. If processType is '1', then the data is retrieved from
 * noOfVotes[] array using Direct Addressing and if '2', then using Hash table.
 * Both runs in O(1) time complexity.
 * 
 */
class ProcessEvmData {
	// processType value of '1' indicates, implementation is Direct Addressing
	// method
	// processType value of '2' indicates, implementation is Hash table method
	static int processType;
	// evmList array stores the record of type EvmData class, which has the
	// attributes from EVM feed file. processType value of '1' or '2' indicates,
	// the list is loaded using Direct Addressing and Hash table
	// implementations respectively
	static EvmData[] evmList;
	// noOfVotes array stores the distinct Voter IDs and its corresponding count
	// of Votes
	static int[] noOfVotes;

	// Constructor to declare the array lists used to store EVM data and Vote
	// Count
	ProcessEvmData() {
		processType = 0;
		// The array size is calculated based on the formula (maximum of 6 digits
		// Candidate ID - minimum of 6 digits Candidate ID +1)
		evmList = new EvmData[EvmConstants.VOTER_ARRAY_SIZE];
		// Array to store distinct Voter ID and corresponding count
		noOfVotes = new int[EvmConstants.CANDIDATE_ARRAY_SIZE];
	}
/*The method loadData accepts input from the user to decide the implementation.
 * if user selects '1', then the data is loaded and stored in EvmData[] array
 * using Direct Addressing and if '2', then using Hash table implementation.
 * While the records are added to EvmData[], the distinct Voter ID is added as a
 * key to another array noOfVotes[] with the corresponding count of votes as the
 * value. This is done to make the COUNT operation time complexity to O(1) and
 * to retrieve the data without for loops.
 */
	static void loadData(int inputType) {

		File evmFile = null; // File variable to read the text file
		Scanner evmScan = null; // Scanner variable to read the Integer attributes
		                        // from the text file
		EvmData evmObj = null; // Declare variable of type EvmData and initialize it
		                       // as null
		try {
			// To open a reference to the EVM feed file
			evmFile = new File("data.txt");
			// Creating Scanner object reference to the File object
			evmScan = new Scanner(evmFile);
			
			// Traversing through the entire EVM feed file
			while (evmScan.hasNextLine()) {
				// Creating an object to store the Candidate and Voter attributes from
				// each line in the file
				evmObj = new EvmData();
				// read the Voter ID attribute from the text file
				evmObj.voterID = evmScan.nextInt();
				// read the Candidate ID attribute from the text file
				evmObj.candidateID = evmScan.nextInt();

				if (inputType == 1) // direct addressing
				{
					/*
					 * Assign value '1' to Class variable processType, to provide
					 * direction to other findCandidate and countOfVotes methods as to how
					 * to handle the underlying data structure while searching for records
					 * as we are using a single array underneath. 1-> Direct Addressing
					 */
					ProcessEvmData.processType = 1;
					/*
					 * create the index value by using KEY - Minimum of Voter ID, which is
					 * (Voter ID - 100000). The object that contains the attributes Voter
					 * Id and Candidate ID is stored to the array list in the index value
					 * generated using Direct Addressing method as explained above.
					 */
					evmList[evmObj.voterID - EvmConstants.VOTER_MIN] = evmObj;
					/*
					 * create the index value by using KEY - Minimum of Candidate ID,
					 * which is Candidate ID - 100 and store it in the noOfVotes array.
					 * The distinct Candidate ID is the array index here and the value is
					 * incremented each time we encounter the same Candidate ID in the
					 * feed file.
					 */
					noOfVotes[evmObj.candidateID - EvmConstants.CANDIDATE_MIN] = noOfVotes[evmObj.candidateID
					    - EvmConstants.CANDIDATE_MIN] + 1;
				} else if (inputType == 2) // hash table
				{
					/*
					 * Assign value '2' to Class variable processType, to provide
					 * direction to other findCandidate and countOfVotes methods as to how
					 * to handle the underlying data structure while searching for records
					 * as we are using a single array underneath. 2-> Hash table
					 */
					ProcessEvmData.processType = 2;
					/*
					 * create the index value by using KEY % array size, which is Maximum
					 * of Voter ID - Minimum of Voter ID +1 the object reference evmObj
					 * that contains the attributes Voter Id and Candidate ID is stored to
					 * the array list in the index/hash value generated using Hash table
					 * method as explained above.
					 */
					evmList[evmObj.voterID % EvmConstants.VOTER_ARRAY_SIZE] = evmObj;
					/*
					 * create the index/hash value by using KEY % array size, which is the
					 * Maximum of Candidate ID - Minimum of Candidate ID +1 and store it
					 * in the noOfVotes array. The value is incremented each time we
					 * encounter the same Candidate ID in the feed file.
					 */
					noOfVotes[evmObj.candidateID
					    % EvmConstants.CANDIDATE_ARRAY_SIZE] = noOfVotes[evmObj.candidateID
					        % EvmConstants.CANDIDATE_ARRAY_SIZE] + 1;
				}
			}
			if (inputType == 1) { // If data is loaded using Direct Addressing
				System.out.println("EVM data loaded to an Array using Direct Addressing Method");
			} else if (inputType == 2) { // If data is loaded using Hash table
				System.out.println("EVM data loaded to an Array using HashTable");
			}
		} catch (FileNotFoundException e) {
			System.out.println("EVM data file not found...");
		} finally {
			// Closing the Scanner resource
			if(evmScan!=null) {
				evmScan.close();
			}
		}
	}

	/**
	 * This method accepts the Voter ID as input and outputs the corresponding
	 * Candidate ID. The value of the processType variable determines the
	 * underlying implementation '1' represents Direct Addressing and '2'
	 * represents Hash Table and the corresponding index value is calculated to
	 * find the Candidate ID
	 */
	static void findCandidate() {
		// Declaring a variable to store Voter ID
		int voterId = 0;
		Scanner vId = null;
		try {
			// Input 6 digit Voter ID
			vId = new Scanner(System.in);
			// Prompt for user input to enter a six digit Voter ID
			System.out.print("Please enter a six digit Voter ID to search : ");
			// Check if he has entered an Integer
			if (vId.hasNextInt()) {
				// If integer is entered, then assign it to a variable
				voterId = vId.nextInt();
				// Check if the entered integer is a six digit number
				if ((voterId >= EvmConstants.VOTER_MIN && voterId <= EvmConstants.VOTER_MAX)) {
					
					// processType value '1' indicates the underlying implementation is
					// Direct Addressing
					if (ProcessEvmData.processType == 1) {
						/*
						 * if the corresponding array value is 'null', it indicates the cell
						 * is empty and there is no corresponding record in the feed for the
						 * Voter ID and hence say the Voter has not cast his vote.
						 */
						if (evmList[voterId - EvmConstants.VOTER_MIN] == null)
							System.out.println("The given Voter has not cast his vote");
						else
							/*
							 * if the cell is not empty, then retrieve the corresponding
							 * Candidate ID by calculating the index using Direct Addressing
							 * method KEY - LOW => voterID - minimum of Voter ID, which is
							 * 100000
							 */
							System.out.println("The Voter ID " + evmList[voterId - EvmConstants.VOTER_MIN].voterID
							    + " has cast his vote for "
							    + evmList[voterId - EvmConstants.VOTER_MIN].candidateID);
					}
					// processType value '2' indicates the underlying implementation is
					// Hash table
					else if (ProcessEvmData.processType == 2) {
						/*
						 * If the corresponding array value is 'null', it indicates the cell
						 * is empty and there is no corresponding record in the feed for the
						 * Voter ID and hence say the Voter has not cast his vote.
						 */
						if (evmList[voterId % EvmConstants.VOTER_ARRAY_SIZE] == null)
							System.out.println("The given Voter has not cast his vote");
						else
							/*
							 * If the cell is not empty, then retrieve the corresponding
							 * Candidate ID by calculating the hash using Hash table method
							 * KEY % Array size => (voterID % Maximum of Voter ID - Minimum of
							 * Voter ID + 1
							 */
							System.out.println(
							    "The Voter ID " + evmList[voterId % EvmConstants.VOTER_ARRAY_SIZE].voterID
							        + " has cast his vote for Candidate ID "
							        + evmList[voterId % EvmConstants.VOTER_ARRAY_SIZE].candidateID);

					}
					// prompt the user to load the data first, if he is trying to call
					// findCandidate method before loading the data
					else if (ProcessEvmData.processType == 0) {
						System.out.println("Load the data before proceeding with other options...");
					}
				} else {
					// If the integer entered is not in the range
					System.out.print("Please enter a valid six digit Voter ID.... ");
				}
			} else {
				// If a non-numeric value is entered
				System.out.print("Please enter a valid six digit integer.... ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// To flush scanner
			vId.next();
		}
	}

	/**
	 * This method accepts the Candidate ID as input and outputs the total votes
	 * received by the Candidate. The value of the processType variable determines
	 * the underlying implementation '1' represents Direct Addressing and '2'
	 * represents Hash Table and the corresponding index value is calculated to
	 * find the Voter ID and its respective count of votes
	 */
	static void countOfVotes() {
		int candidateId = 0;
		Scanner cId = null;
		try {
			// Input 3 digit Candidate ID
			cId = new Scanner(System.in);
			// Prompt for user input to enter a three digit Candidate ID
			System.out.print("Please enter a three digit Candidate ID to count votes : ");
			
			// Check if he has entered an Integer
			if (cId.hasNextInt()) {
				// If integer is entered, then assign it to a variable
				candidateId = cId.nextInt();
				// Check if the entered integer is a three digit number
				if ((candidateId >= EvmConstants.CANDIDATE_MIN
				    && candidateId <= EvmConstants.CANDIDATE_MAX)) {
					// processType value '1' indicates the underlying implementation is
					// Direct Addressing
					if (ProcessEvmData.processType == 1) {
						// Index value to retrieve the count of votes is calculated using
						// Direct Addressing method using
						// (KEY-LOW) => (Candidate ID - Minimum Candidate id value)
						System.out.println("The Candidate ID " + candidateId + " has secured "
						    + noOfVotes[candidateId - EvmConstants.CANDIDATE_MIN] + " votes");
					}
					// processType value '2' indicates the underlying implementation is
					// Hash
					// Table
					else if (ProcessEvmData.processType == 2) {
						// Index value to retrieve the count of votes is calculated using
						// Hash table method using (KEY % Array Capacity) => (Candidate ID %
						// Array size)
						System.out.println("The Candidate ID " + candidateId + " has secured "
						    + noOfVotes[candidateId % EvmConstants.CANDIDATE_ARRAY_SIZE] + " votes");
					}
					// prompt the user to load the data first, if he is trying to call
					// countOfVotes method before loading the data
					else if (ProcessEvmData.processType == 0) {
						System.out.println("Load the data before proceeding with other options...");
					}
				} else {
					// If the integer entered is not in the range
					System.out.print("Please enter a valid three digit Candidate ID.... ");
				}
			} else {
				// If a non-numeric value is entered
				System.out.print("Please enter a valid three digit integer.... ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// To flush scanner
			cId.next();
		}
	}
}
